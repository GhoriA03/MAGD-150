function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255, 1);
    background(220);
  
  noStroke();
  fill(255, 255, 0);
  ellipse(80, 80, 100, 100);
  fill(0, 150, 255);
  ellipse(250, 200, 80, 80);
  fill(200, 100, 255, 0.8);
  ellipse(330, 300, 60, 60);
  fill(255);
  triangle(50, 350, 55, 340, 60, 350);
}

function draw() {
}