function setup() {
  createCanvas(400, 400);
  background(15);
  
  noStroke();
  for (let i = 0; i < 80; i++) {
    let x = random(width);
    let y = random(height);
    let starSize = random(1, 4); 
    let brightness = random(150, 255);
    fill(brightness);
    ellipse(x, y, starSize, starSize);

  }

  noStroke();
  fill(255, 255, 200, 60);
  ellipse(300, 100, 140, 140);
  
for (let r = 100; r > 0; r -= 5) {
    let c = map(r, 100, 0, 180, 230);
    fill(c);
    ellipse(300, 100, r, r);
 }
  fill(180, 180, 180, 180);
  ellipse(285, 90, 20, 20);
  fill(160, 160, 160, 150); 
  ellipse(315, 115, 15, 15);
  fill(200, 200, 200, 120);
  ellipse(295, 115, 12, 12);
  fill(170, 170, 170, 150);
  ellipse(310, 85, 10, 10);
  
      
  stroke(195);
  strokeWeight(3);
  strokeCap(ROUND);
  line(90, 160, 160, 145);
  
  stroke(230);
  strokeWeight(2);
  strokeJoin(BEVEL);
  fill(100);
  rect(60, 260, 28, 18);
  line(74, 260, 74, 240);
}

function draw() {

}